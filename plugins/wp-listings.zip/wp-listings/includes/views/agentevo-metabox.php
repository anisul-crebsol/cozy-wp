<?php
echo '<a href="http://www.agentevolution.com" target="_blank"><img src="' . WP_LISTINGS_URL . 'images/ae-themes-ad.png" alt="Premium WordPress Child Themes by Agent Evolution"></a>';